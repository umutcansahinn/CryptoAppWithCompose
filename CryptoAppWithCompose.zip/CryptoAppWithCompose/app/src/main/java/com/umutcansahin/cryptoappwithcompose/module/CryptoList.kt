package com.umutcansahin.cryptoappwithcompose.module

class CryptoList : ArrayList<CryptoListItem>()