package com.umutcansahin.cryptoappwithcompose.module

data class CryptoItem(
    val id: String,
    val logo_url: String,
    val name: String
)