package com.umutcansahin.cryptoappwithcompose.view

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun CryptoDetailScreen(
    id:String,
    price:String,
    navController: NavController
) {

}