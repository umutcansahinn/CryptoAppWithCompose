package com.umutcansahin.cryptoappwithcompose.module

data class CryptoListItem(
    val currency: String,
    val price: String
)