package com.umutcansahin.cryptoappwithcompose.module

class Crypto : ArrayList<CryptoItem>()