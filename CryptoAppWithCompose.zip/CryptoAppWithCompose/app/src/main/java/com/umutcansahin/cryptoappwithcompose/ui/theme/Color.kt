package com.umutcansahin.cryptoappwithcompose.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val RichBlack = Color(0xFF050505)
val BlueMunsell = Color(0xFF0B7B8A)
val Bone = Color(0xFFDDDBCB)
val Alabaster = Color(0xFFE9F5F2)